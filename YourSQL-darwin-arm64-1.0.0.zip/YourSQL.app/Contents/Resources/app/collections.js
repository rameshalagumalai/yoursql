const mysql = require("mysql");

const mainFrame = document.getElementById("main-frame");
const noDb = document.getElementById("no-db");
const dbNameView = document.getElementById("db-name");
const resultView = document.getElementById("result");
const queryForm = document.getElementById("query-form");
const executeBtn = document.getElementById("execute-btn");
const executingBtn = document.getElementById("executing-btn");
const refreshBtn = document.getElementById("refresh-btn");
const closeConnBtn = document.getElementById("close-conn-btn");
const searchType = document.getElementById("button-addon1");
const searchForCols = document.getElementById("search-for-cols");
const searchForTables = document.getElementById("search-for-tables");
const searchItem = document.getElementById("search-item");
const searchInput = document.getElementById("search-input");
const searchForm = document.getElementById("search-form");
const savedQueriesForm = document.getElementById("saved-queries-form");
const savedQueriesContainer = document.getElementById("saved-queries-container");
const editor = document.getElementById("editor");
const closeSavedQueriesBtn = document.getElementById("close-saved-queries-btn");
const saveQueryBtn = document.getElementById("save-query-btn");
const newSavedQueryName = document.getElementById("new-saved-query-name");
const newSavedQuery = document.getElementById("new-saved-query");
const showTablesBtn = document.getElementById("show-tables-btn");
const colors = ["success", "warning", "info"];


const connectionData = JSON.parse(localStorage.getItem("connection"));
var db = localStorage.getItem("db");
var isDb = true;

if (!connectionData) {
    window.location.href = "index.html";
}
const connection = mysql.createConnection(connectionData);
connection.connect((err) => {
    if (err) {
        window.location.href = "index.html";
        return;
    }
});

if (!db) {
    mainFrame.classList.add("d-none");
    noDb.classList.remove("d-none");
    isDb = false;
} else {
    changeDb(db, null);
}

connection.query("SHOW DATABASES", (err, databases) => {
    if (err) {
        alert(err.message);
        return;
    }
    const databasesList = document.getElementById("databases");
    databases.forEach(({ Database }) => {
        databasesList.innerHTML += `<p${(db === Database) ? ' id="active-db"' : ''} onclick="changeDb('${Database}', event.target)" class="p-3 mb-0 border-bottom cursor-pointer navigation-link">${Database}</p>`
    });
});


var savedQueries = JSON.parse(localStorage.getItem("savedQueries"));
if (!savedQueries) {
    savedQueries = [];
    localStorage.setItem("savedQueries", JSON.stringify(savedQueries));
}
setUpSavedQueries(savedQueries);

function setUpSavedQueries(queries) {
    savedQueriesContainer.innerHTML = "";
    queries.map(({ color, name, query }, i) => {
        savedQueriesContainer.innerHTML += `<div class="p-2 bg-${color}-subtle mb-3 shadow"><div class="d-flex align-items-center mb-1"><h6 class="f-600 mb-0">${name}</h6><button class="btn ms-auto me-3 p-0 text-success" onclick="performQueryFromSavedQueries(${i})"><i class="fa-solid fa-play"></i></button><button class="btn me-3 p-0 text-secondary" onclick="deleteSavedQuery(${i})"><i class="fa-solid fa-trash"></i></button><button class="btn p-0" onclick="copyText(${i})"><i class="fa-regular fa-clone"></i></button></div><p class="mb-0">${query}</p></div>`
    });
}

function changeDb(dbName, target) {

    connection.query(`USE ${dbName}`, (err) => {
        if (err) {
            resultView.innerHTML = `<div class="alert alert-danger shadow border-0 rounded-4" role="alert">${err.message}</div>`;
            return;
        }
        dbNameView.innerHTML = dbName;
        resultView.innerHTML = `<div class="alert alert-info shadow border-0 rounded-4" role="alert">Current database: ${dbName}</div>`;
        window.localStorage.setItem("db", dbName);
        if (!isDb) {
            noDb.classList.add("d-none");
            mainFrame.classList.remove("d-none");
            isDb = true;
        }

        
        if (target) {
            const activeElement = document.getElementById("active-db");
            if (activeElement) {
                activeElement.removeAttribute("id");
            }
            target.setAttribute("id", "active-db");
        }
        db = dbName;
    });
}

queryForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const query = new FormData(queryForm).get("query").trim();
    const lcQuery = query.toLowerCase();
    if (lcQuery.includes("use ") && (lcQuery.indexOf("use ") === 0)) {
        var dbName = query.substring(query.indexOf(" ") + 1);
        if (dbName.includes(";")) {
            dbName = dbName.substring(0, dbName.indexOf(";"));
        }
        changeDb(dbName, null);
        return;
    }
    performQuery(query, lcQuery);
});

function performQuery(query, lcQuery) {
    if (lcQuery.includes("show tables")) {
        getTables(query);
        return;
    }
    loadExecuteButton();
    connection.query(query, (err, rows) => {
        if (err) {
            resultView.innerHTML = `<div class="alert alert-danger shadow border-0 rounded-4" role="alert">${err.message}</div>`;
            unLoadExecuteButton();
            return;
        }
        if (!Array.isArray(rows)) {
            if (lcQuery.includes("create database") || lcQuery.includes("drop database")) {
                if (lcQuery.includes("drop database")) {
                    var dbName = query.substring(query.lastIndexOf(" ") + 1);
                    if (dbName.includes(";")) {
                        dbName = dbName.substring(0, dbName.indexOf(";"));
                    }
                    if (db === dbName) {
                        localStorage.removeItem("db");
                    }
                }
                location.reload();
                return;
            }
            resultView.innerHTML = `<div class="alert alert-success shadow border-0 rounded-4" role="alert">Execution successful<br/>Affected rows: ${rows.affectedRows}</div>`;
            unLoadExecuteButton();
            return;
        }
        if (rows.length === 0) {
            resultView.innerHTML = `<div class="alert alert-warning shadow border-0 rounded-4" role="alert">No records found</div>`;
            unLoadExecuteButton();
            return;
        }
        resultView.innerHTML = `<table class="table table-striped table-bordered bg-white"><thead><tr id="headings"></tr></thead><tbody id="rows"></tbody></table>`;
        const tableHeadings = document.getElementById("headings");
        const tablesRows = document.getElementById("rows");
        const words = lcQuery.split(" ");
        if (!(words.includes(" join ") || words.includes("union") || words.includes("show") || (words.includes("desc")&&(words.indexOf("desc")===1)) || words.includes("count")) && words.includes("*")) {
            var tableName = query.split(" ")[words.indexOf("from") + 1];
            if (tableName.includes(";")) {
                tableName = tableName.substring(0, tableName.indexOf(";"));
            }
            connection.query(`DESC ${tableName}`, (err, columns) => {
                if (err) {
                    resultView.innerHTML = `<div class="alert alert-danger shadow border-0 rounded-4" role="alert">Execution successful<br/>Something went wrong</div>`;
                    unLoadExecuteButton();
                    return;
                }
                columns.forEach(({ Field, Key }) => {
                    switch (Key) {
                        case "PRI":
                            tableHeadings.innerHTML += `<th scope"col">${Field} <i class="fa-solid fa-key text-warning"></i></th>`;
                            break;
                        case "MUL":
                            tableHeadings.innerHTML += `<th scope"col">${Field} <i class="fa-solid fa-plane text-secondary"></i></th>`;
                            break;
                        default:
                            tableHeadings.innerHTML += `<th scope"col">${Field}</th>`;
                    }
                });
                populateRows();
            });
        } else {
            const firstRow = rows[0];
            for (const column in firstRow) {
                tableHeadings.innerHTML += `<th scope"col">${column}</th>`;
            }
            populateRows();
        }
        function populateRows() {
            rows.map((row, i) => {
                tablesRows.innerHTML += `<tr id="row-${i}"></tr>`;
                const rowView = document.getElementById(`row-${i}`);
                for (const column in row) {
                    rowView.innerHTML += `<td>${row[column]}</td>`
                }
            });
            unLoadExecuteButton();
        }
    });
}

searchForCols.addEventListener("click", (e) => setUpSearch(e));
searchForTables.addEventListener("click", (e) => setUpSearch(e));

function setUpSearch(e) {
    const searchItemVal = e.target.getAttribute("search-item");
    searchType.innerHTML = searchItemVal;
    searchInput.setAttribute("placeholder", `Search for ${searchItemVal}`);
    searchItem.value = searchItemVal;
}

searchForm.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!db) {
        return;
    }
    const formData = new FormData(searchForm);
    const searchItemVal = formData.get("search-item");
    const searchKey = formData.get("search-key");
    var query;
    if (searchItemVal === "Columns") {
        query = `SELECT COLUMN_NAME, TABLE_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = "${db}" AND COLUMN_NAME LIKE "%${searchKey}%"`;
        getColumns(query);
    } else {
        query = `SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = "${db}" AND TABLE_NAME LIKE "%${searchKey}%"`;
        getTables(query);
    }
});

function getTables(query) {
    loadExecuteButton();
    connection.query(query, (err, tables) => {
        if (err) {
            resultView.innerHTML = `<div class="alert alert-danger shadow border-0 rounded-4" role="alert">${err.message}</div>`;
            unLoadExecuteButton();
            return;
        }
        if (tables.length === 0) {
            resultView.innerHTML = `<div class="alert alert-warning shadow border-0 rounded-4" role="alert">No tables found</div>`;
            unLoadExecuteButton();
            return;
        }
        const heading = Object.keys(tables[0])[0];
        resultView.innerHTML = `<table class="table table-striped table-bordered bg-white"><thead><tr"><th>${heading}</th></tr></thead><tbody id="rows"></tbody></table>`;
        const tablesRows = document.getElementById("rows");
        tables.map((table, i) => {
            const tableName = table[heading];
            tablesRows.innerHTML += `<tr id="row-${i}"></tr>`;
            const rowView = document.getElementById(`row-${i}`);
            const query = `SELECT * FROM ${tableName};`;
            rowView.innerHTML += `<td class="text-primary cursor-pointer" onclick="performQuery('${query}', '${query.toLowerCase()}'); displayQueryInEditor('${query}')">${tableName}</td>`
        });
        unLoadExecuteButton();
    });
}

function getColumns(query) {
    loadExecuteButton();
    connection.query(query, (err, columns) => {
        if (err) {
            resultView.innerHTML = `<div class="alert alert-danger shadow border-0 rounded-4" role="alert">${err.message}</div>`;
            unLoadExecuteButton();
            return;
        }
        if (columns.length === 0) {
            resultView.innerHTML = `<div class="alert alert-warning shadow border-0 rounded-4" role="alert">No columns found</div>`;
            unLoadExecuteButton();
            return;
        }
        resultView.innerHTML = `<table class="table table-striped table-bordered bg-white"><thead><tr"><th>COLUMN_NAME</th><th>TABLE_NAME</th></tr></thead><tbody id="rows"></tbody></table>`;
        const tablesRows = document.getElementById("rows");
        columns.map(({COLUMN_NAME, TABLE_NAME}, i) => {
            tablesRows.innerHTML += `<tr id="row-${i}"></tr>`;
            const rowView = document.getElementById(`row-${i}`);
            const columnQuery = `SELECT ${COLUMN_NAME} FROM ${TABLE_NAME};`;
            const tableQuery = `SELECT * FROM ${TABLE_NAME};`;
            rowView.innerHTML += `<td class="text-primary cursor-pointer" onclick="performQuery('${columnQuery}', '${columnQuery.toLowerCase()}'); displayQueryInEditor('${columnQuery}')">${COLUMN_NAME}</td>`;
            rowView.innerHTML += `<td class="text-primary cursor-pointer" onclick="performQuery('${tableQuery}', '${tableQuery.toLowerCase()}'); displayQueryInEditor('${tableQuery}')">${TABLE_NAME}</td>`;
        });
        unLoadExecuteButton();
    });
}

savedQueriesForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const formData = new FormData(savedQueriesForm);
    savedQueries.push({
        color: colors[Math.floor(Math.random() * 3)],
        name: formData.get("query-name"),
        query: formData.get("query").replace("\n", " ")
    });
    savedQueriesForm.reset();
    setUpSavedQueries(savedQueries);
    localStorage.setItem("savedQueries", JSON.stringify(savedQueries));
});

showTablesBtn.addEventListener("click", () => {
    performQuery("SHOW TABLES;", "show tables;");
    displayQueryInEditor("SHOW TABLES;");
});

refreshBtn.addEventListener("click", () => {
    location.reload();
});

saveQueryBtn.addEventListener("click", () => {
    newSavedQuery.value = editor.value;
    newSavedQueryName.focus();
    newSavedQueryName.select();
});

closeConnBtn.addEventListener("click", () => {
    window.localStorage.removeItem("connection");
    window.localStorage.removeItem("db");
    window.location.href = "index.html";
});

function displayQueryInEditor(query) {
    editor.value = query;
}

function loadExecuteButton() {
    executeBtn.classList.add("d-none");
    executingBtn.classList.remove("d-none");
}

function unLoadExecuteButton() {
    executingBtn.classList.add("d-none");
    executeBtn.classList.remove("d-none");
}

function performQueryFromSavedQueries(index) {
    const query = savedQueries[index].query;
    performQuery(query, query.toLowerCase());
    displayQueryInEditor(query);
    closeSavedQueriesBtn.click();
} 

function copyText(index) {
    navigator.clipboard.writeText(savedQueries[index].query);
}

function deleteSavedQuery(index) {
    savedQueries = savedQueries.filter((savedQuery, i) => {
        return (
            i !== index
        );
    });
    setUpSavedQueries(savedQueries);
    localStorage.setItem("savedQueries", JSON.stringify(savedQueries));
}