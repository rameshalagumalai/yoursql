const mysql = require("mysql");

const connectionForm = document.getElementById("connection-form");
const submitBtn = document.getElementById("submit-btn");
const loadingBtn = document.getElementById("loading-btn");
const loader = document.getElementById("loader");

window.onload = () => {
    const connectionData = JSON.parse(localStorage.getItem("connection"));
    if (connectionData) {
        const connection = mysql.createConnection(connectionData);
        connection.connect((err) => {
            if (!err) {
                window.location.href = "collections.html";
                return;
            }
        });
        return;
    }
    loader.classList.add("d-none");
    connectionForm.classList.remove("d-none");
}

connectionForm.addEventListener("submit", (event) => {
    event.preventDefault();
    submitBtn.classList.add("d-none");
    loadingBtn.classList.remove("d-none");
    const connFomrData = new FormData(connectionForm);
    const connData = {
        host: connFomrData.get("host"),
        user: connFomrData.get("user"),
        password: connFomrData.get("password")
    }
    const conn = mysql.createConnection(connData);
    conn.connect((err) => {
        if (err) {
            const errorAlert = document.getElementById("alert");
            errorAlert.innerHTML = err.message;
            errorAlert.classList.remove("d-none");
        } else {
            window.location.href = "collections.html"
            localStorage.setItem("connection", JSON.stringify(connData));
        }
    });
    loadingBtn.classList.add("d-none");
    submitBtn.classList.remove("d-none");
});